# task-5: Mini Project - To-Do List App

Create a to-do list application using HTML, CSS, and JavaScript. Include features to add, edit, delete, and mark tasks as completed. Use CSS to style the app and make it responsive for different screen sizes.

Skills:
HTML
CSS
JavaScript
