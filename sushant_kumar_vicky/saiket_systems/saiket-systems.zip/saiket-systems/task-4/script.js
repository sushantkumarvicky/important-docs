const quizData = [
  {
    question: "What does HTML stand for?",
    options: [
      "Hyper Text Markup Language",
      "High Text Machine Language",
      "Hyper Tool Multi Language",
      "None of the above",
    ],
    correct: 0,
  },
  {
    question: "Which language is used for styling web pages?",
    options: ["HTML", "JQuery", "CSS", "XML"],
    correct: 2,
  },
  {
    question: "Which is a JavaScript framework?",
    options: ["Laravel", "Django", "Angular", "Flask"],
    correct: 2,
  },
];

let currentQuestion = 0;
let score = 0;

const questionEl = document.getElementById("question");
const optionsEl = [
  document.getElementById("opt0"),
  document.getElementById("opt1"),
  document.getElementById("opt2"),
  document.getElementById("opt3"),
];
const nextBtn = document.getElementById("nextBtn");

function loadQuestion() {
  const q = quizData[currentQuestion];
  questionEl.innerText = q.question;

  optionsEl.forEach((opt, index) => {
    opt.innerText = q.options[index];
  });

  // clear previous selection
  document.querySelectorAll('input[name="answer"]').forEach((el) => {
    el.checked = false;
  });
}

function getSelected() {
  let selected = null;
  document.querySelectorAll('input[name="answer"]').forEach((el) => {
    if (el.checked) {
      selected = parseInt(el.value);
    }
  });
  return selected;
}

nextBtn.addEventListener("click", () => {
  const selected = getSelected();

  // ✅ validation
  if (selected === null) {
    alert("Please select an answer!");
    return;
  }

  if (selected === quizData[currentQuestion].correct) {
    score++;
  }

  currentQuestion++;

  if (currentQuestion < quizData.length) {
    loadQuestion();
  } else {
    document.querySelector(".quiz-container").innerHTML = `
      <h2>Your Score: ${score}/${quizData.length}</h2>
      <button onclick="location.reload()">Restart</button>
    `;
  }
});

// initial load
loadQuestion();
