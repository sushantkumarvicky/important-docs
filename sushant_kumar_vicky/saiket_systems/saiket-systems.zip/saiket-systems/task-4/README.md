# Task 4: Build a simple quiz application using JavaScript.

Description:
Create a quiz application using JavaScript with at least 3 multiple-choice questions.
Add functionality to move to the next question and display the score at the end.
Ensure users cannot proceed without selecting an answer by adding basic validation.

Skills:
Basics JavaScript
DOM Manipulation
