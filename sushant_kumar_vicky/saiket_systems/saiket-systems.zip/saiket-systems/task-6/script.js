document.getElementById("ctaBtn").addEventListener("click", () => {
  alert("Welcome! Let's build something amazing 🚀");
});

const cards = document.querySelectorAll(".service-card");

cards.forEach((card) => {
  card.addEventListener("click", () => {
    // close others
    cards.forEach((c) => c.classList.remove("active"));

    // open clicked
    card.classList.toggle("active");
  });
});

const steps = document.querySelectorAll(".step");

steps.forEach((step) => {
  step.addEventListener("click", () => {
    steps.forEach((s) => s.classList.remove("active"));
    step.classList.add("active");
  });
});
