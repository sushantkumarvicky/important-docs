Task 6: Real-world Simulation - Clone a Webpage

Description:
Choose a simple webpage, like a product or company landing page, and recreate its layout and design using HTML and CSS.
Add interactivity with JavaScript, such as a button or form functionality, to make it more dynamic.

Skills:
HTML
CSS
JavaScript
