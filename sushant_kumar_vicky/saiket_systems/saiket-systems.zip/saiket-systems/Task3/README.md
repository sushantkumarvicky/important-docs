#Task 3 (Create a responsive webpage layout)

Description:
Design a webpage with four sections: a header, a sidebar, a main content area and a footer.
Use CSS to make the layout responsive, ensuring it looks good on all screen sizes. Apply media queries to switch between a grid layout for desktops and a stacked layout for mobile devices.

Skills:
HTML
CSS
